window.addEventListener("load", function () {
  const photoButton = document.getElementById("photoButton");

  // 以下にコードを記載
  photoButton.addEventListener("click",()=>{
    takePhoto();
  });
  // コードの記載終わり
});
