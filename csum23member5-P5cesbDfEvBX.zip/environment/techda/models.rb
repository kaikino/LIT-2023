require 'bundler/setup'
Bundler.require

ActiveRecord::Base.establish_connection

class Ranking < ActiveRecord::Base

end
